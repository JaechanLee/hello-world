package gs.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.stereotype.Service;

import io.github.bonigarcia.wdm.WebDriverManager;

@Service
public class AlarmCrawler {

	public Map<String, String> accidentCrawler() {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://its.go.kr/traffic/accident.do");
		
		WebElement elem = driver.findElement(By.xpath("//*[@id=\"searchForm\"]/fieldset/div[1]/div[1]/div[2]/b"));
				
		elem.click();
		elem = driver.findElement(By.xpath("//*[@id=\"searchForm\"]/fieldset/div[1]/div[1]/div[3]/div/ul/li[2]"));
		elem.click();
		elem = driver.findElement(By.xpath("//*[@id=\"searchBtn\"]"));
		elem.click();
		
		List<WebElement> elemList_1 = driver.findElements(By.xpath("//*[@id=\"skip\"]/section/div[2]/table/tbody/tr/td[2]"));
		List<WebElement> elemList_2 = driver.findElements(By.xpath("//*[@id=\"skip\"]/section/div[2]/table/tbody/tr/td[3]"));

		Map<String, String> resultMap = new HashMap<>();
		
		for (int i = 0; i < elemList_1.size(); i++) {
			String elem_modified_1 = (elemList_1.get(i).getAttribute("innerHTML")).replaceAll("<td>|</td>|<br>|<strong>|</strong>|</td>|\r|\n|\t", "");
			String elem_modified_2 = (elemList_2.get(i).getAttribute("innerHTML")).replaceAll("<td>|</td>|<br>|<strong>|</strong>|</td>|\r|\n|\t", "");
			System.out.println(elem_modified_1);
			System.out.println(elem_modified_2);
			resultMap.put(i + 1 + "", elem_modified_1 + " " + elem_modified_2);
		}
		
		return resultMap;
	}
	
	public Map<String, String> fireCrawler() {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://safecity.seoul.go.kr/acdnt/fireIndex.do");
		
		List<WebElement> elemList = driver.findElements(By.xpath("//*[@id=\\\"content_go\\\"]/div[2]/div/div[2]/ul/li"));

		Map<String, String> resultMap = new HashMap<>();
		
		for (int i = 0; i < elemList.size(); i++) {		
			String elem_stringified = (elemList.get(i).getAttribute("innerHTML"));
			System.out.println(elem_stringified);
		}
		
		return resultMap;
	}
}
